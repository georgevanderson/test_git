import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

class Movie{
	private String genre;
	private String title;
	private String director;
	private List<String> writers;
	private List<String> actors;
	private String description;
	private String year;
	private String rating;
	Movie(String genre, String title, String director, List<String> writer, List<String> actor, String description, String year, String rating){
		this.genre=genre;
		this.title = title;
		this.director = director;
		this.writers=writer;
		this.actors = actor;
		this.description=description;
		this.year=year;
		this.rating=rating;
	}
	
	public String getGenre(){
		return genre;
	}
	public String getTitle(){
		return title;
	}
	public String getDirector(){
		return director;
	}
	public List<String> getWriters(){
		return writers;
	}
	public List<String> getActors(){
		return actors;
	}
	public String getDescription(){
		return description;
	}
	public String getYear(){
		return year;
	}
	public String getRating(){
		if(rating!=""){
		return rating;
	}else{
		return "N/A";
	}
	}
	
}

class Event{
	private String action;
	private String movie;
	private String rating;
	
	Event(String act, String mov, String rat){
		action =act;
		movie = mov;
		rating = rat;
	}
	
	public String getRating(){
		return rating;
	}
	public String getMovie(){
		return movie;
	}
	public String getAction(){
		return action;
	}
}

class User{
	User(String first, String last, String username, String password, List<String> follow, List<Event> actions){
		this.first=first;
		this.last=last;
		this.username=username;
		this.password=password;
		this.actions = actions;
		names = follow;
	}
	User(User old){
		first = old.getFirst();
		last = old.getLast();
		username = old.getUsername();
		password= old.getPassword();
		names = old.getFollowing();
		actions = old.getActions();
		
		
	}
	private String first;
	private String last;
	private String username;
	private String password;
	private List<String> names;
	private List<Event> actions;
	private String[] followers;
	private List<User> following;
	
	public void addFollower(User user){
		following.add(new User(user));
	}
	public String getFirst(){
		return first;
	}
	public String getLast(){
		return last;
	}
	public String getName(){
		return (first+ " " + last);
	}
	public String getUsername(){
		return username;
	}
	public String getPassword(){
		return password;
	}
	public List<String> getFollowing(){
		return names;
	}
	public List<Event> getActions(){
		return actions;
	}
	
	public static void printUserInfo(User user){
		System.out.println(user.getName());
		System.out.println("Username: " + user.getUsername());
		System.out.println("Password: " + starPass(user.getPassword()));
		System.out.println("Following: ");
		for(String s : user.getFollowing()){
			System.out.println(s);
		}
		
	}
	
	public void printFeed(){
		printActions(this);
		System.out.println("yo");
		System.out.println("hello" + following.isEmpty());
		for(User u : following){
			printActions(u);
		}
	}
	public void printActions(User user){
		for(Event ev : user.getActions()){
			if(ev.getRating()!=""){
			System.out.println(user.getUsername() +" " + ev.getAction() + " the movie " + ev.getMovie()+ " an " + ev.getRating());;
			}else{
			System.out.println(user.getUsername() + " "+ ev.getAction() + " the movie " + ev.getMovie());
			}
			}
	}

	
	private static String starPass(String input){
		char first = input.charAt(0);
		char last = input.charAt(input.length()-1);
		StringBuffer sb = new StringBuffer();
		sb.append(first);
		for(int i =0; i <input.length()-2; i ++){
			sb.append("*");
		}
		sb.append(last);
		return sb.toString();
		
		
		
	}
}

public class Assignment1 {
	public static void searchUsers(List<User> users){
		Scanner scan = new Scanner(System.in);
		String name = scan.nextLine();
		boolean found = false;
		for(User user : users){
	
			if(name.equalsIgnoreCase(user.getUsername())){
				System.out.println("1 Result:");
				System.out.println(name);
				found = true;
			}
		}
		if(!found){
			System.out.println("0 Results");
		}
	}
	
	
	public static void searchMovies(List<Movie> movies){
		Scanner scan = new Scanner(System.in);
	       
		int status =0;
		while(status < 1 || status >5){
		System.out.println("1. Search by Actor");
		System.out.println("2. Search by Title");
		System.out.println("3. Search by Genre");
		System.out.println("4. Back to login Menu");
		status = scan.nextInt();
		}
		
		if(status ==1){
			searchByActor(movies);
		}else if (status ==2){
			searchByTitle(movies);
		}else if(status == 3){
			searchByGenre(movies);
		}else{
		
		}
	}
	
	private static void searchByGenre(List<Movie> movies){
		Scanner scan = new Scanner(System.in);
		String name = scan.nextLine();
		boolean found = false;
		System.out.println( "Result:");
		for(Movie movie : movies){
	
			if(name.equalsIgnoreCase(movie.getGenre())){
			
				System.out.println(movie.getTitle());
				found = true;
			}
		}
		if(!found){
			System.out.println("0");
		}
		
	}
	private static void searchByTitle(List<Movie> movies){
		Scanner scan = new Scanner(System.in);
		String name = scan.nextLine();
		boolean found = false;
		System.out.println( "Result:");
		for(Movie movie : movies){
	
			if(name.equalsIgnoreCase(movie.getTitle())){
			
				System.out.println(movie.getTitle());
				found = true;
			}
		}
		if(!found){
			System.out.println("0");
		}
	}
	private static void searchByActor(List<Movie> movies){
		Scanner scan = new Scanner(System.in);
		String name = scan.nextLine();
		boolean found = false;
		System.out.println("Result:");
		for(Movie movie: movies){
			for(String s : movie.getActors()){
				if(s.equalsIgnoreCase(name)){
					
					System.out.println(movie.getTitle());
					found = true;
				}
			}
		}
		
	}
	
	public static boolean login(List<User> users, List<Movie> movies){
		Scanner scan = new Scanner(System.in);
		int attempts =3;
		System.out.println("Please enter your username");
		boolean found = false;
	
		while(attempts >0 && found == false){
		
			String name = scan.nextLine();
			
			
			for(User user : users){	
			
				if(name.equalsIgnoreCase(user.getUsername())){
					found =true;
				
					int passattempts =3;
					boolean passfound = false;
					System.out.println("Please enter your password");
					while(passattempts>0 && passfound ==false){
						
						String pass = scan.nextLine();
						if(pass.equalsIgnoreCase(user.getPassword())){
							System.out.println("her");
							mainMenu(user, users, movies);
						}else{
							passattempts--;
							System.out.println("That was incorrect. You have " + attempts + " more attempts");
							
						}
					}
				
				}
			
				}
			}
			if(found == false){
				attempts--;
				System.out.println("That was incorrect. You have " + attempts + " more attempts");
			}
		
			return false;
			
		}
		
	

	public static boolean mainMenu(User user, List<User> users, List<Movie> movies){
		Scanner scan = new Scanner(System.in);
		int status =0;
		while(status <1 || status>6){
			System.out.println("1. Search Users");
			System.out.println("2. Search Movies");
			System.out.println("3. View Feed");
			System.out.println("4. View Profile");
			System.out.println("5. Logout");
			System.out.println("6. Exit");
			status = scan.nextInt();
			if(status==1){
				searchUsers(users);
			}else if (status ==2){
				searchMovies(movies);
			}else if (status ==3){
				user.printFeed();
			}else if (status ==4){
				user.printUserInfo(user);
			}else if (status ==5){
				login(users, movies);
			}else{
				return false;
			}
		}
		
		return true;
	}
	
	public static int start(List<User> users, List<Movie> movies){
		Scanner scan = new Scanner(System.in);
       
		int status =0;
		while(status<1 || status >2){
		System.out.println("1. Login");
		System.out.println("2. Exit");
        status = scan.nextInt();
        if(status<0 || status >2){
        	System.out.println("You have entered an invalid command, pleas try again");
        }
		}
		
		if(status ==1){
			System.out.println("here");
			login(users, movies);
			return 0;
		}else{
			return 0;
		}
		
		
	}
/*	public static void makeFollowers(List<User> users){
		for(User u : users){
			for(String s: u.getFollowing()){
				for(User a: users){
					System.out.println("3");
					System.out.println("user " + a.getUsername());		
					String fixed = s.replaceAll("\\s+","");
					System.out.println("string " + fixed);
					if(fixed.equalsIgnoreCase(a.getUsername())){
						System.out.println("4");
						a.printUserInfo(a);
						u.addFollower(a);
					}
				}
			}
		}
	}
*/
   public static void main(String[] args){
List<User> users = new ArrayList<User>();
List<Movie> movies = new ArrayList<Movie>();
      try {	
         File inputFile = new File("input2.txt");
         DocumentBuilderFactory dbFactory 
            = DocumentBuilderFactory.newInstance();
         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
         Document doc = dBuilder.parse(inputFile);
         doc.getDocumentElement().normalize();
         System.out.println("Root element :" 
            + doc.getDocumentElement().getNodeName());
         
         NodeList userList = doc.getElementsByTagName("user");
        NodeList fakeList = doc.getElementsByTagName("movies");
        Node mNode = fakeList.item(0);
    
            Element fElement = (Element) mNode; 
        
        NodeList movieList = fElement.getElementsByTagName("movie");
        
         for (int temp = 0; temp < movieList.getLength(); temp++) {
            
             System.out.println("\nCurrent Element :" 
                + mNode.getNodeName());
             if (mNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) mNode; 
                String title = eElement.getElementsByTagName("title").item(0).getTextContent();
               System.out.println("title" + title);
                String genre = eElement.getElementsByTagName("genre").item(0).getTextContent();
                String description = eElement.getElementsByTagName("description").item(0).getTextContent();
                String director = eElement.getElementsByTagName("director").item(0).getTextContent();
                String year = eElement.getElementsByTagName("year").item(0).getTextContent();
                NodeList writers = eElement.getElementsByTagName("writers");
                String rating = eElement.getElementsByTagName("rating").item(0).getTextContent();
                System.out.println("here");
                
                
                List<String> writer = new ArrayList<String>();
                for(int j=0; j <writers.getLength(); j++){
             	   writer.add(writers.item(j).getTextContent());
                }
                NodeList actors = eElement.getElementsByTagName("actors");
                
                List<String> actor = new ArrayList<String>();
                for(int j=0; j <actors.getLength(); j++){
             	   actor.add(actors.item(j).getTextContent());
                }
                movies.add(new Movie(genre, title, director,  writer,  actor, description,year, rating));
             }
         }
         System.out.println("----------------------------");
         for (int temp = 0; temp < userList.getLength(); temp++) {
            Node nNode = userList.item(temp);
            System.out.println("\nCurrent Element :" 
               + nNode.getNodeName());
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
               Element eElement = (Element) nNode;
               
                  String firstname = eElement
                  .getElementsByTagName("fname")
                  .item(0)
                  .getTextContent();
               String lastname= eElement
                  .getElementsByTagName("lname")
                  .item(0)
                  .getTextContent();
               String username = eElement
                  .getElementsByTagName("username")
                  .item(0)
                  .getTextContent();
               String password = eElement
                       .getElementsByTagName("password")
                       .item(0)
                       .getTextContent();
               NodeList following = eElement.getElementsByTagName("following");
               
               List<String> follow = new ArrayList<String>();
               for(int j=0; j <following.getLength(); j++){
            	   follow.add(following.item(j).getTextContent());
               }
               NodeList eventList = eElement.getElementsByTagName("event");
               List<Event> actions = new ArrayList<Event>();
               for(int k = 0; k < eventList.getLength(); k++){
            	   String action = eElement.getElementsByTagName("action").item(k).getTextContent();
            	   String movie = eElement.getElementsByTagName("movie").item(k).getTextContent();
            	   
            	   String rating = eElement.getElementsByTagName("rating").item(k).getTextContent();
            	   actions.add(new Event(action,movie,rating));
               }
              
               /*eElement
                  .getElementsByTagName("marks")
                  .item(0)
                  .getTextContent());
                  */
               users.add(new User(firstname, lastname, username, password, follow, actions));
              
            }
         }
         start(users,movies);
      //   makeFollowers(users);
      } catch (Exception e) {
         e.printStackTrace();
      }

   //for(User user: users){
	 //  user.printFeed();
  // }
   }
}